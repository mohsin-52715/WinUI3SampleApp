#include "dummy.hpp"

int CALLBACK
WinMain([[maybe_unused]] HINSTANCE pInstance, [[maybe_unused]] HINSTANCE pPrevInstance, [[maybe_unused]] LPSTR pCmdLine, [[maybe_unused]] int pShowCmd) {
    
    startapp();
}