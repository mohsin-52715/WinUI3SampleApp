
#if         (TW_KERNEL_WINDOWS)

void function()
{
}
#endif